# XrayR

一个可以轻松支持多种面板的 Xray 后端框架。

一个基于 Xray 的后端框架，支持 V2Ray、Trojan、Shadowsocks 协议，易于扩展，并支持多面板对接。

如果您喜欢这个项目，可以点击右上角的 **STAR+WATCH** 来持续关注本项目的进展。

## 免责声明

本项目仅为我个人学习、开发和维护。我不保证任何可用性，也不对使用此软件造成的任何后果负责。

## 功能特性

-   永久开源免费。
-   支持 V2Ray、Trojan、Shadowsocks 多种协议。
-   支持 VLESS、XTLS 等新特性。
-   支持单实例对接多面板、多节点，无需重复启动。
-   支持限制在线 IP。
-   支持节点端口级别和用户级别的速率限制。
-   配置简单明了。
-   修改配置可自动重启实例。
-   易于编译和升级，可快速更新核心版本并支持 Xray-core 的新特性。

## 功能列表

| 功能 | V2Ray | Trojan | Shadowsocks |
| :--- | :---: | :---: | :---: |
| 获取节点信息 | √ | √ | √ |
| 获取用户信息 | √ | √ | √ |
| 用户流量统计 | √ | √ | √ |
| 服务器信息上报 | √ | √ | √ |
| 自动申请 TLS 证书 | √ | √ | √ |
| 自动续签 TLS 证书 | √ | √ | √ |
| 在线人数统计 | √ | √ | √ |
| 在线用户数限制 | √ | √ | √ |
| 审计规则 | √ | √ | √ |
| 节点端口限速 | √ | √ | √ |
| 用户级别限速 | √ | √ | √ |
| 自定义 DNS | √ | √ | √ |

## 支持的面板

| 面板 | V2Ray | Trojan | Shadowsocks |
| :--- | :---: | :---: | :---: |
| sspanel-uim | √ | √ | √ (单端口多用户和 V2Ray-Plugin) |
| v2board | √ | √ | √ |
| PMPanel | √ | √ | √ |
| ProxyPanel | √ | √ | √ |
| V2RaySocks | √ | √ | √ |
| BunPanel | √ | √ | √ |

## 软件安装

### 一键安装

```bash
wget -N https://raw.githubusercontent.com/Sysrous/XrayR/refs/heads/master/install.sh && bash install.sh
```

## 文档

📚 **现在提供全面的文档！**

-   **[快速开始指南](./docs/快速开始指南.md)** - 开始使用 XrayR 的安装与配置
-   **[架构设计](./docs/架构设计文档.md)** - 深入了解 XrayR 的架构与原理
-   **[API 开发指南](./docs/API开发文档.md)** - 学习如何为新面板添加支持
-   **[文档索引](./docs/README.md)** - 浏览所有可用文档

## 致谢

-   [Project X](https://github.com/XTLS/)
-   [V2Fly](https://github.com/v2fly)
-   [VNet-V2ray](https://github.com/ProxyPanel/VNet-V2ray)
-   [Air-Universe](https://github.com/crossfw/Air-Universe)

## 许可协议

[Mozilla Public License Version 2.0](https://github.com/Aqr-K/XrayR/blob/master/LICENSE)